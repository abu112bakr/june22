public class Node{
  public Object element;
  public Node next;
  
  public Node(Object e, Node n){
    element =e ;
    next = n;
    
  }
  
}